console.log("*******MONGOOSE*******");
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/mean_exam_db_1', {useNewUrlParser: true});